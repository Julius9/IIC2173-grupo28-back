#!/bin/bash

echo "Validating service"
